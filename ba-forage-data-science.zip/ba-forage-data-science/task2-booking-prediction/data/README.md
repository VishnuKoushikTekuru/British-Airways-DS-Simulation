# Data

This folder is intentionally empty in the repository.

The source dataset, `customer_booking.csv`, is Forage/British Airways program
material and is not redistributed here. To run the notebook, download it from your
Forage task page and place it in this folder before running
`notebooks/Getting_Started.ipynb`.
