# Task 2 — Predictive Modeling of Customer Bookings

A Forage / BA Data Science project: predicting whether a customer completes a
holiday booking, and identifying which variables and customer profiles drive that
outcome.

## Problem

BA wants to be proactive rather than reactive with customers — using booking data
to predict who is likely to complete a booking, so marketing can be targeted before
the customer even arrives at the airport.

## Approach

1. **Explored** 50,000 bookings (`customer_booking.csv`) — no missing values, but a
   ~15% positive class imbalance and two high-cardinality categoricals (`route`: 799
   unique, `booking_origin`: 104 unique).
2. **Prepared the data**: frequency-encoded `route` and `booking_origin` (avoiding a
   one-hot blow-up that would dilute the signal across dozens of sparse columns),
   capped extreme outliers in `purchase_lead` and `length_of_stay`, and engineered
   new features (`total_extras`, time-of-day buckets, lead-time buckets, weekend flag).
3. **Trained a RandomForestClassifier** (200 trees, `class_weight="balanced"` to
   handle the imbalance), validated with 5-fold stratified cross-validation.
4. **Evaluated** on a held-out test set: ROC-AUC, precision, recall, F1, confusion matrix.
5. **Interpreted the model two ways**:
   - Permutation importance (robust to RandomForest's bias toward high-cardinality
     features, unlike the default impurity-based importance)
   - SHAP values, to get both magnitude *and* direction of each feature's effect
6. **Profiled high-likelihood customers** using predicted probabilities, and
   validated the model's real-world lift by comparing the top-decile actual booking
   rate against the overall base rate.

## Key results

| Metric | Value |
|---|---|
| Cross-validated ROC-AUC (5-fold) | 0.755 (std ±0.006 — stable) |
| Held-out test ROC-AUC | 0.762 |
| Recall / Precision | 74% / 28% |
| Top-decile lift | 2.8x (41.8% vs. 15.0% base rate) |

## Key findings

- **Origin market is the strongest single driver**, but the effect is
  country-specific rather than simply volume-based: Australia (17,872 bookings)
  converts at just 5%, while Malaysia (7,174 bookings) converts at 34%.
- **Shorter trips, shorter-haul flights, and wanting optional extras** (baggage,
  preferred seat, in-flight meals) all push toward completion.
- **Booking via Internet (not Mobile)**, closer to the travel date, for a round
  trip with fewer passengers, also increases the likelihood of completion.
- Most time-based engineered features (weekend flag, hour bucket, flight day)
  contributed negligibly — several were statistically indistinguishable from noise.
- **Best-fit customer profile**: a solo or couple traveler on a shorter, round-trip,
  shorter-haul itinerary who wants most optional extras.

## Verdict

The data is viable for **prioritizing marketing spend** by likelihood-to-book
(model concentrates real bookers into the top decile at nearly 3x the base rate),
but the ~0.76 ROC-AUC ceiling means it should not be used for high-confidence
predictions about any single customer.

## A note on methodology choices

An example answer for this task encoded `booking_origin` as one-hot region columns
and used RandomForest's default impurity-based importance. Both choices dilute or
bias the origin signal — one-hot splits it across many sparse columns, and
impurity-based importance is known to favor continuous/high-cardinality features.
This project deliberately used frequency encoding (to preserve the full origin
signal in one feature) and permutation importance + SHAP (to correct for that bias),
which is why the results differ substantially from that example.

## Repo structure

```
├── README.md
├── notebooks/
│   └── Getting_Started.ipynb        # full analysis, step by step
└── outputs/
    ├── BA_Booking_Prediction_Summary.pptx
    ├── final_shap_direction.csv
    └── origin_country_summary.csv
```

## How to run

```bash
pip install pandas scikit-learn shap matplotlib jupyter
jupyter notebook notebooks/Getting_Started.ipynb
```

Place `customer_booking.csv` in this folder before running (excluded from this repo
— it's Forage/BA program material, not redistributed here).

## Limitations & next steps

- Origin market's country-specific effect (e.g., Australia vs. Malaysia) isn't
  explained by anything in this dataset — likely reflects factors like local
  competing airlines, currency, or booking culture that aren't captured here.
- If BA can supply richer customer-level data (loyalty status, past purchase
  history, marketing engagement), that would likely raise the ROC-AUC ceiling
  beyond what booking metadata alone can achieve.
