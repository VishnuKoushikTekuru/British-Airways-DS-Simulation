# Data

This folder is intentionally empty in the repository.

The source dataset, `British Airways Summer Schedule Dataset - Forage Data Science Task 1.xlsx`,
is Forage/British Airways program material and is not redistributed here. To run the
notebook, download it from your Forage task page and place it in this folder before
running `notebooks/Lounge_Eligibility_lookup.ipynb`.
