# British Airways Data Science Program

Two projects completed as part of the BA / Forage Data Science job simulation.

## Projects

### [Task 1 — Lounge Eligibility Lookup](./task1-lounge-eligibility)
Built a reusable lookup table estimating what percentage of passengers on a flight
are eligible for each of BA's Terminal 3 lounge tiers, grouped by haul type, arrival
region, and time of day — designed to scale to future schedules without needing
specific flight or aircraft data.

### [Task 2 — Predictive Modeling of Customer Bookings](./task2-booking-prediction)
Built a RandomForest classifier to predict whether a customer completes a booking,
using permutation importance and SHAP to identify which variables actually drive
completion, and profiled which customers are most likely to book. Summarized in a
single slide for a business audience.

## Repo structure

```
├── README.md
├── task1-lounge-eligibility/
│   ├── README.md
│   ├── notebooks/
│   └── outputs/
└── task2-booking-prediction/
    ├── README.md
    ├── notebooks/
    └── outputs/
```

Each project folder has its own README with full methodology, findings, and
instructions to run.
